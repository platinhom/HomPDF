<!DOCTYPE html>
<html>
<body>

16<br>4<br>60<br>1.6666666666667<br>4   

</body>
</html>