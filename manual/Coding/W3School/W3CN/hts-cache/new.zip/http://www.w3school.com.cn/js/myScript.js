function myFunction()
{
document.getElementById("demo").innerHTML="My First External JavaScript";
}
