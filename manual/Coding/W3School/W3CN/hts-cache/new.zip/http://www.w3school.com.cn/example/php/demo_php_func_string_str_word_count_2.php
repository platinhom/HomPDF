<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => I
    [2] => love
    [7] => Shanghai
)
  
</body>
</html>