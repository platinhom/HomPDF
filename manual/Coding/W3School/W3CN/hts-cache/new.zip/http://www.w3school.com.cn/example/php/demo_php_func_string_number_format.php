<!DOCTYPE html>
<html>
<body>

5,000,000<br>5,000,000.00<br>5.000.000,00  
</body>
</html>