<!DOCTYPE html>
<html>
<body>

/example/php/demo_php_global_server.php<br>www.w3school.com.cn<br>www.w3school.com.cn<br>http://www.w3school.com.cn/tiy/s.asp?f=demo_php_global_server<br>Mozilla/4.5 (compatible; HTTrack 3.0x; Windows 98)<br>/example/php/demo_php_global_server.php
</body>
</html>