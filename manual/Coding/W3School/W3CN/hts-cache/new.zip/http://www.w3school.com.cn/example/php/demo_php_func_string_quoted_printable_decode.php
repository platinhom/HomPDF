<!DOCTYPE html>
<html>
<body>

I
love
Shanghai!
</body>
</html>