<!DOCTYPE html>
<html>
<body>

I love Shanghai! What a nice day! 

</body>
</html>