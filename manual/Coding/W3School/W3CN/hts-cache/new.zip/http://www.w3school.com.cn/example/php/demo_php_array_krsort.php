<!DOCTYPE html>
<html>
<body>

Key=Steve, Value=37<br>Key=Peter, Value=43<br>Key=Bill, Value=35<br>
</body>
</html>