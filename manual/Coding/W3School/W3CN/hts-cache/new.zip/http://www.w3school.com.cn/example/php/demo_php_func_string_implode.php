<!DOCTYPE html>
<html>
<body>

Hello World! I love Shanghai!
</body>
</html>