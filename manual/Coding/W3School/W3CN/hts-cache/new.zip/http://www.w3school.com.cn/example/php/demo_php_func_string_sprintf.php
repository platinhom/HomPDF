<!DOCTYPE html>
<html>
<body>

There are 2 million cars in Shanghai.  
</body>
</html>