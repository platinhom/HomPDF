 <!DOCTYPE html>
<html>
<body>

Welcome to W3School.com.cn!<br>Welcome to W3School.com.cn!  

</body>
</html>