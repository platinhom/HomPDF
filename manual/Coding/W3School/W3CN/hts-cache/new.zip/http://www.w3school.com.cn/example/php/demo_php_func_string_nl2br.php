<!DOCTYPE html>
<html>
<body>

One line.<br />
Another line.  
</body>
</html>