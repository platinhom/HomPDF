<!DOCTYPE html>
<html>
<body>

There are 9 million bicycles in Beijing.  
</body>
</html>