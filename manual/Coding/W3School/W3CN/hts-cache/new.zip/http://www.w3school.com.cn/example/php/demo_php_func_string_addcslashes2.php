<!DOCTYPE html>
<html>
<body>

Welcome to Shanghai!<br>Welcome to Sh\angh\ai!<br>Welcome to \Shanghai!<br>
</body>
</html>