 <!DOCTYPE html>
<html>
<body>

I love &quot;PHP&quot;.
</body>
</html>