<!DOCTYPE html>
<html>
<body>

Who's Bill Gates? This is not safe in a database query.<br>Who\'s Bill Gates? This is safe in a database query.  

</body>
</html>