<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Sha
    [1] => ngh
    [2] => ai
)
  
</body>
</html>