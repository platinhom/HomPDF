<!DOCTYPE html>
<html>
<body>

bool(true)
<br>bool(false)
<br>bool(false)
<br>bool(true)
<br>bool(false)
<br>bool(true)
   

</body>
</html>