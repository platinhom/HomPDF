<!DOCTYPE html>
<html>
<body>

5,000<br>4,999.90  
</body>
</html>