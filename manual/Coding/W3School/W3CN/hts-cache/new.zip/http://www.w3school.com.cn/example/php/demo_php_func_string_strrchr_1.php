<!DOCTYPE html>
<html>
<body>

What a beautiful day!  
</body>
</html>