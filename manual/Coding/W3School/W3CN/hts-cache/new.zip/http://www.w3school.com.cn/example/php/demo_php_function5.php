<!DOCTYPE html>
<html>
<body>

5 + 10 = 15<br>7 + 13 = 20<br>2 + 4 = 6
</body>
</html>