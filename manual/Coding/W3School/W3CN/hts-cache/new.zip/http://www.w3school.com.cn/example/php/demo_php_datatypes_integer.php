<!DOCTYPE html>
<html>
<body>

int(5985)
<br>int(-345)
<br>int(140)
<br>int(39)

</body>
</html>