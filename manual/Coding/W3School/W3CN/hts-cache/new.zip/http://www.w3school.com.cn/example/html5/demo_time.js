function getDateTime()
{
var d=new Date();
document.getElementById('timePara').innerHTML=d;
}