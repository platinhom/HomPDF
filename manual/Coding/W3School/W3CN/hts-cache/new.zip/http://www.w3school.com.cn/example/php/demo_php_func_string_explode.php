<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => Hello
    [1] => world.
    [2] => I
    [3] => love
    [4] => Shanghai!
)
  

</body>
</html>