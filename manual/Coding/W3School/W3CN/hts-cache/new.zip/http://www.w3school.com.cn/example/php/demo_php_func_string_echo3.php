<!DOCTYPE html>
<html>
<body>

Hello world!<br>I love shanghai!
</body>
</html>