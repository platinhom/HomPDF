<!DOCTYPE html>
<html>
<body>

Key=Peter, Value=43<br>Key=Steve, Value=37<br>Key=Bill, Value=35<br>
</body>
</html>