<!DOCTYPE html>
<html>
<body>

1 \+ 1 = 2<br>1 \* 1 = 1<br>Could you borrow me 5\$\?<br>Are you not e<br>The caret \[ \^ \] Looks like a hat!<br>  
</body>
</html>