<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => one,two,three,four
)
Array
(
    [0] => one
    [1] => two,three,four
)
Array
(
    [0] => one
    [1] => two
    [2] => three
)

</body>
</html>