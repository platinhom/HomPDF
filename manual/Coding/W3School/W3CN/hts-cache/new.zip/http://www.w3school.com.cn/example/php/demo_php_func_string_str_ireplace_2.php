<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => B
    [1] => 
    [2] => !
)
  
</body>
</html>