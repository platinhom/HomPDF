<!DOCTYPE HTML>
<html> 
<body>

<form action="/demo/welcome.php" method="post">
������<input type="text" name="name"><br>
���ʣ�<input type="text" name="email"><br>
<input type="submit">
</form>

</body>
</html>