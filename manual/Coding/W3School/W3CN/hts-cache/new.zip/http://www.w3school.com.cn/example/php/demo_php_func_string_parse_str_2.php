<!DOCTYPE html>
<html>
<body>

Array
(
    [name] => Bill
    [age] => 60
)
  
</body>
</html>