<!DOCTYPE html>
<html>
<body>

Learn PHP<br>Study PHP at W3School.com.cn<br>My car is a Volvo
</body>
</html>