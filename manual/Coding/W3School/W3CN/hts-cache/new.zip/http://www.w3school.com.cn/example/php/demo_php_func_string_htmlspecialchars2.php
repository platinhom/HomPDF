 <!DOCTYPE html>
<html>
<body>

Bill &amp; 'Steve'<br>Bill &amp; &#039;Steve&#039;<br>Bill &amp; 'Steve'
</body>
</html>