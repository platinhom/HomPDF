<!DOCTYPE html>
<html>
<body>

An example of a<br>
long word is:<br>
Supercalifragul<br>
istic  
</body>
</html>