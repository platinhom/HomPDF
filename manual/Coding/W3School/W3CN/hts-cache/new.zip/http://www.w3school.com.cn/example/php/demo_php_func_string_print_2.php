<!DOCTYPE html>
<html>
<body>

I love Shanghai!<br>What a nice day!
</body>
</html>