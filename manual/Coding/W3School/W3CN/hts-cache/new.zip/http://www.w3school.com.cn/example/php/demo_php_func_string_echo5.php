<!DOCTYPE html>
<html>
<body>

Bill Gates is 60 years old.
</body>
</html>