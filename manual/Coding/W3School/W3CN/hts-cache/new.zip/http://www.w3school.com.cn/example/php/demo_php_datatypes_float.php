<!DOCTYPE html>
<html>
<body>

float(10.365)
<br>float(2400)
<br>float(8.0E-5)

</body>
</html>