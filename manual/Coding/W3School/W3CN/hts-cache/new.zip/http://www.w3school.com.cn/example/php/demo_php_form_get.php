<!DOCTYPE HTML>
<html> 
<body>

<form action="/demo/welcome_get.php" method="get">
������<input type="text" name="name"><br>
���ʣ�<input type="text" name="email"><br>
<input type="submit">
</form>

</body>
</html>