<!DOCTYPE html>
<html>
<body>

Array
(
    [&] => &amp;
    ["] => &quot;
    [<] => &lt;
    [>] => &gt;
)

</body>
</html>