<!DOCTYPE html>
<html>
<body>

Welcome to Shanghai!<br>\Welcome to \Shanghai!<br>W\e\l\c\o\m\e \t\o S\h\a\n\g\h\a\i!<br>W\el\com\e to Sh\an\gh\ai!  
</body>
</html>