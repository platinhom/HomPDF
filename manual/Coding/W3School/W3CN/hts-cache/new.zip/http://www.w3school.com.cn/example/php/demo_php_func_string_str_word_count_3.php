<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => I
    [1] => love
    [2] => Shanghai
    [3] => good
    [4] => morning
)
Array
(
    [0] => I
    [1] => love
    [2] => Shanghai
    [3] => &
    [4] => good
    [5] => morning
)
  
</body>
</html>