<!DOCTYPE html>
<html>
<body>

Hello World! I love Shanghai!<br>Hello+World!+I+love+Shanghai!<br>Hello-World!-I-love-Shanghai!<br>HelloXWorld!XIXloveXShanghai!
</body>
</html>