<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => If
    [1] => you
    [2] => divide
    [3] => 4
    [4] => by
    [5] => 2
    [6] => you'll
    [7] => get
    [8] => 2
)
  
</body>
</html>