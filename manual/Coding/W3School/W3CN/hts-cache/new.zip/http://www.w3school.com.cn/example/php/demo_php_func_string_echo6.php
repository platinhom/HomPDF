<!DOCTYPE html>
<html>
<body>

This text
spans multiple
lines.
</body>
</html>