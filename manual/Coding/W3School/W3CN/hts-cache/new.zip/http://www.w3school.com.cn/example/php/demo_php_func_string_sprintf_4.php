<!DOCTYPE html>
<html>
<body>

[Hello]<br>[   Hello]<br>[Hello   ]<br>[000Hello]<br>[***Hello]<br>[Hello wo]<br>  
</body>
</html>