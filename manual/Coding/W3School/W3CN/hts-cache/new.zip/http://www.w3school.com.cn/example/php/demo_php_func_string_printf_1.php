<!DOCTYPE html>
<html>
<body>

123.000000
</body>
</html>