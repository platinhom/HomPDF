<!DOCTYPE html>
<html>
<body>

2 + 2 = 4
</body>
</html>