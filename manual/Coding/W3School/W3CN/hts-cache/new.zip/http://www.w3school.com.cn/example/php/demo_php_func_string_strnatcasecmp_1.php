<!DOCTYPE html>
<html>
<body>

��׼�ַ����Ƚ�<br>Array
(
    [0] => pic01
    [1] => pic1
    [2] => pic10
    [3] => pic100
    [4] => pic2
    [5] => pic20
    [6] => pic200
    [7] => pic30
)
<br>��Ȼ˳���ַ����Ƚ�<br>Array
(
    [0] => pic01
    [1] => pic1
    [2] => pic2
    [3] => pic10
    [4] => pic20
    [5] => pic30
    [6] => pic100
    [7] => pic200
)
  
</body>
</html>