<!DOCTYPE html>
<html>
<body>

Hello world!<br>5<br>10.5
</body>
</html>