<!DOCTYPE html>
<html>
<body>

Roses are red<br>Roses are $color
</body>
</html>