<!DOCTYPE html>
<html>
<body>

Hello world! I love Shanghai!  

</body>
</html>