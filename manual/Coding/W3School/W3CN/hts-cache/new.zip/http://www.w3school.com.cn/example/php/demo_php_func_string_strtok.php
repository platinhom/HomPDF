<!DOCTYPE html>
<html>
<body>

Hello<br>world.<br>Beautiful<br>day<br>today.<br>  
</body>
</html>