<!DOCTYPE html>
<html>
<body>

My car is red<br>My house is <br>My boat is <br>  

</body>
</html>