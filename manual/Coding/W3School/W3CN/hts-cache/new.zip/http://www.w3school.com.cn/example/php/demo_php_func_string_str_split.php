<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => S
    [1] => h
    [2] => a
    [3] => n
    [4] => g
    [5] => h
    [6] => a
    [7] => i
)
  
</body>
</html>