<!DOCTYPE html>
<html>
<body>

10<br>120<br>25<br>30<br>2<br>3   

</body>
</html>