<!DOCTYPE html>
<html>
<body>

Hello <b>world!</b>  
</body>
</html>