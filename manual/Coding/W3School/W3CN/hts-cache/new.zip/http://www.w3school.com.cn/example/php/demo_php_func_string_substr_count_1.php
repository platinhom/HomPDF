<!DOCTYPE html>
<html>
<body>

12<br>2<br>2<br>1<br>0<br>  
</body>
</html>