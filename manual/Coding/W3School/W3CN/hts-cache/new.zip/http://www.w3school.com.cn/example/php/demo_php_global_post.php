<!DOCTYPE html>
<html>
<body>

<form method="post" action="/example/php/demo_php_global_post.php">
Name: <input type="text" name="fname">
<input type="submit">
</form>


</body>
</html>