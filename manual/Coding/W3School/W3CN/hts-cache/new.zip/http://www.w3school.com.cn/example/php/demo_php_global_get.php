<!DOCTYPE html>
<html>
<body>

<a href="/demo/test_get.php?subject=PHP&web=W3school.com.cn">���� $GET</a>

</body>
</html>