{ 
  "firstName": "Bill",
  "lastName": "Gates",
  "age": 60
}