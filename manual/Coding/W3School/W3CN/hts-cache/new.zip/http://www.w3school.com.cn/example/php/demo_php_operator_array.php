<!DOCTYPE html>
<html>
<body>

array(4) {
  ["a"]=>
  string(3) "red"
  ["b"]=>
  string(5) "green"
  ["c"]=>
  string(4) "blue"
  ["d"]=>
  string(6) "yellow"
}
<br>bool(false)
<br>bool(false)
<br>bool(true)
<br>bool(true)
<br>bool(true)
   

</body>
</html>