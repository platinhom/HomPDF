 <!DOCTYPE html>
<html>
<body>

Welcome to W3School.com.cn!<br>greeting  

</body>
</html>