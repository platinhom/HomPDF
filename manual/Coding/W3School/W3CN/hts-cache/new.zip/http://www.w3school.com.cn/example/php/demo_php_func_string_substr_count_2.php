<!DOCTYPE html>
<html>
<body>

This is nice  
</body>
</html>