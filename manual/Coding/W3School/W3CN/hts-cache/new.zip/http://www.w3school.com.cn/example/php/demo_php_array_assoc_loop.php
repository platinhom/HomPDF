<!DOCTYPE html>
<html>
<body>

Key=Bill, Value=35<br>Key=Steve, Value=37<br>Key=Peter, Value=43<br>
</body>
</html>