<!DOCTYPE html>
<html>
<body>

Array
(
    [0] => blue
    [1] => pink
    [2] => green
    [3] => yellow
)
�滻����1  
</body>
</html>