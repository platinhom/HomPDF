<!DOCTYPE html>
<html>
<body>

Hi earth  
</body>
</html>